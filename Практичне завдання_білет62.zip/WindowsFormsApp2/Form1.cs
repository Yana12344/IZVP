﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void InputRichTextBox()
        {
            foreach (Student s in Students.students)
            {
                richTextBox1.Text += s.initials + " " + s.birthDate.ToString("dd-MM-yyyy") + " " + s.group + " ";
                foreach (int grade in s.grades)
                {
                    richTextBox1.Text += grade + "; ";
                }
                richTextBox1.Text += "  " + s.avg;
                richTextBox1.Text += '\n';
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Students.Deserialize();
            InputRichTextBox();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Students.Serialize();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^[2-5]{1},{1}[2-5]{1},{1}[2-5]{1},{1}[2-5]{1},{1}[2-5]{1},{1}[2-5]{1},{1}[2-5]{1}$");
            if (textBox1.Text != "" && textBox3.Text != "" && maskedTextBox1.Text != "" && regex.IsMatch(textBox4.Text))
            {
                richTextBox1.Text = "";
                String[] strings = textBox4.Text.Split(',');
                List<int> grades = new List<int>();
                for (int i = 0; i < strings.Length; i++)
                {
                    grades.Add(Convert.ToInt32(strings[i]));
                }
                Students.students.Add(new Student(textBox1.Text, DateTime.ParseExact(maskedTextBox1.Text, "dd-MM-yyyy", null), textBox3.Text, grades));
                Students.Serialize();
                InputRichTextBox();
            }
            else
            {
                MessageBox.Show("Invalid data!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if ((e.KeyChar <= 49 || e.KeyChar >= 54) && number != 8 && number != 44)
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.ShowDialog();
        }
    }
}
