﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class Student
    {
        public String initials { set; get; }
        public DateTime birthDate { set; get; }
        public String group{ set; get; }
        public List<int> grades { set; get; }
        public double avg { set; get; }

        public Student()
        {
            this.initials = "";
            this.group = "";
            this.avg = 0;
        }

        public Student(String initials, DateTime birthDate,String group, List<int> grades)
        {
            this.initials = initials;
            this.birthDate = birthDate;
            this.group= group;
            this.grades = grades;
            double s = 0;
            for (int i= 0;i<grades.Count;i++)
            {
                s += grades.ElementAt(i);
            }
            s /= grades.Count;
            avg = s;
        }
    }

    [Serializable]
    public static class Students
    {
        public static List<Student> students { set; get; } = new List<Student>();
        public static void Serialize()
        {
            Serializator.SerializeXML<List<Student>>(Students.students, "students");
        }

        public static void Deserialize()
        {
            Students.students=Serializator.DeserializeXML<List<Student>>(Students.students, "students");
        }
    }


}
