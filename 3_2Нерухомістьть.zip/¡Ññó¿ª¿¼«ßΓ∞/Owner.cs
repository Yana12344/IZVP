﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RealEstate
{
    class Owner
    {
        private String addess;
        private String phoneNumber;
    }
}
