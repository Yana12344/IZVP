﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YanaHeal
{
    [Serializable]
    public class Medicament
    {
        public string name;
        public int count;
        public decimal price;
        public  string country;
        public DateTime manufactureDate;
        public DateTime endUseDate;
        public Medicament() { }
    }
    public static class Medicaments
    {
        public static List<Medicament> medicaments = new List<Medicament>();
    }
}
