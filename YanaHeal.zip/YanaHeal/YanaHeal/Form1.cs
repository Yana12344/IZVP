﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YanaHeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            loadDelegate += GetMedicaments;
            loadDelegate += ClearFields;
            loadDelegate += LoadStatistics;
        }

        delegate void LoadDelegate();

        LoadDelegate loadDelegate;

        private void ClearFields()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
        }

        private void LoadStatistics()
        {
            if (Medicaments.medicaments.Count != 0)
            {
                textBox3.Text = Medicaments.medicaments.Max(m => m.price).ToString();
                textBox4.Text = Medicaments.medicaments.Min(m => m.price).ToString();
                int uCount = Medicaments.medicaments.Count(m => m.country == "Україна");
                if (Medicaments.medicaments.Count != 0)
                {
                    textBox6.Text = ((decimal)(uCount * 100.0) / (decimal)Medicaments.medicaments.Count).ToString();
                    textBox5.Text = (100.0m - Convert.ToDecimal(textBox6.Text)).ToString();
                }
            }
        }

        private void GetMedicaments()
        {
            dataGridView1.Rows.Clear();
            foreach(Medicament m in Medicaments.medicaments)
            {
                dataGridView1.Rows.Add(m.name, m.count, m.price,m.country, m.manufactureDate, m.endUseDate);
            }
        }

        private void GetLowTimeStoredMedicaments()
        {
            MessageBox.Show(string.Join("\n", Medicaments.medicaments.Where(m =>
             ((m.endUseDate - m.manufactureDate).Days) / 30 <= 3).Select(m => m.name).ToList()));
        }


        private void Form1_Load(object sender, EventArgs e)
        {
           Medicaments.medicaments = 
                XMLSerialization.DeserializeXML<List<Medicament>>("medicaments");
            loadDelegate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GetLowTimeStoredMedicaments();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           if(textBox1.Text!=""&&
                textBox2.Text!=""&&
                numericUpDown1.Value!=0&&
                numericUpDown2.Value != 0)
            {
                if(dateTimePicker1.Value<dateTimePicker2.Value)
                {
                    if(!Medicaments.medicaments.Any(m=>m.name==textBox1.Text))
                    {
                        Medicaments.medicaments.Add(new Medicament
                        {
                            name = textBox1.Text,
                            country = textBox2.Text,
                            count = Convert.ToInt32(numericUpDown1.Value),
                            price = numericUpDown2.Value,
                            manufactureDate=dateTimePicker1.Value,
                            endUseDate=dateTimePicker2.Value
                        });
                        MessageBox.Show("OK!");
                        XMLSerialization.SerializeXML<List<Medicament>>(ref Medicaments.medicaments, "medicaments");
                        loadDelegate();
                    }
                    else
                    {
                        MessageBox.Show("Ліки з такою назвою вже існують!");
                    }
                }
                else
                {
                    MessageBox.Show("Дата виготовлення не може бути пізніше, ніж дата кінцевого вживання!");
                }
            }
           else
            {
                MessageBox.Show("Спочатку заповніть поля!");
            }
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            loadDelegate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
