﻿ using System;

namespace ChineseGame
{
    class Program
    {
        static void Main(string[] args)
        {
            new Game(10).startGame();
        }
    }
}
