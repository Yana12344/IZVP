﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            bool b;
            foreach (Student st in Students.students)
            {
                b = true;
                foreach (int grade in st.grades)
                {
                    if (grade == 5)
                    {
                        b = false;
                        break;
                    }
                }
                if (b)
                {
                    richTextBox1.Text += st.initials + " " + st.birthDate.ToString("dd-MM-yyyy") + " " + st.group + " ";
                    foreach (int grade in st.grades)
                    {
                        richTextBox1.Text += grade + "; ";
                    }
                    //richTextBox1.Text += "5" + '\n';
                }
            }
        }
    }
}
